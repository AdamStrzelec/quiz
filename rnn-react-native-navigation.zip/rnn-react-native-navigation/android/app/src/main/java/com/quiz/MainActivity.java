package com.quiz;

import com.reactnativenavigation.NavigationActivity;

public class MainActivity extends NavigationActivity {

}
